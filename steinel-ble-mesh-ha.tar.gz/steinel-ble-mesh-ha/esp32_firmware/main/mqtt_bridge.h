#pragma once
#include "esp_err.h"
#include "ble_mesh.h"

typedef struct {
    const char *broker_url;  // z.B. "mqtt://192.168.1.10:1883"
    const char *username;
    const char *password;
    const char *client_id;
} mqtt_bridge_config_t;

esp_err_t mqtt_bridge_init(const mqtt_bridge_config_t *config);

/** Wird intern von BLE-Mesh-Callbacks aufgerufen */
void mqtt_bridge_on_node_added(const steinel_node_t *node);
void mqtt_bridge_on_state_changed(const steinel_node_t *node);

/** Basis-Topic: steinel_mesh/<addr_hex>/... */
#define MQTT_BASE_TOPIC     "steinel_mesh"
#define MQTT_DISCOVERY_BASE "homeassistant"
