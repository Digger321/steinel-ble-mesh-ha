/**
 * mqtt_bridge.c  –  MQTT-Bridge zwischen BLE Mesh und Home Assistant
 *
 * - Veröffentlicht HA MQTT Auto-Discovery beim ersten Erscheinen eines Knotens
 * - Mappt Licht/Sensor-Zustände auf MQTT-Topics
 * - Empfängt Steuerbefehle von HA und ruft BLE-Mesh-Funktionen auf
 */

#include "mqtt_bridge.h"
#include "ble_mesh.h"

#include "esp_log.h"
#include "mqtt_client.h"
#include "cJSON.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

static const char *TAG = "MQTT_BRIDGE";
static esp_mqtt_client_handle_t s_client = NULL;

// ─── Topic-Hilfsfunktionen ────────────────────────────────────────────────────
static void make_topic(char *buf, size_t len,
                        const char *addr_hex, const char *suffix)
{
    snprintf(buf, len, "%s/%s/%s", MQTT_BASE_TOPIC, addr_hex, suffix);
}

static void make_ha_discovery_topic(char *buf, size_t len,
                                     const char *component,
                                     const char *addr_hex,
                                     const char *object_id)
{
    snprintf(buf, len, "%s/%s/%s_%s/config",
             MQTT_DISCOVERY_BASE, component, addr_hex, object_id);
}

static void addr_to_hex(uint16_t addr, char *buf)
{
    snprintf(buf, 5, "%04X", addr);
}

// ─── HA MQTT Auto-Discovery ───────────────────────────────────────────────────
/**
 * Veröffentlicht Discovery-Payloads für alle Entities eines Steinel-Knotens:
 *  - light (Licht mit Helligkeit)
 *  - binary_sensor (Bewegung)
 *  - sensor (Beleuchtungsstärke)
 *  - select (Modus: Auto/Dauerlicht/Aus)
 *  - number (Nachlaufzeit, Empfindlichkeit, Dämmerungsschwelle)
 *  - switch (Softlichtstart aktivieren)
 */
static void publish_ha_discovery(const steinel_node_t *node)
{
    char addr_hex[5];
    addr_to_hex(node->unicast_addr, addr_hex);

    // ── 1. Licht ─────────────────────────────────────────────────────────────
    {
        char disc_topic[128], state_topic[80], cmd_topic[80];
        make_ha_discovery_topic(disc_topic, sizeof(disc_topic), "light", addr_hex, "light");
        make_topic(state_topic, sizeof(state_topic), addr_hex, "light/state");
        make_topic(cmd_topic,   sizeof(cmd_topic),   addr_hex, "light/set");

        cJSON *root = cJSON_CreateObject();
        cJSON_AddStringToObject(root, "name", node->name);
        cJSON_AddStringToObject(root, "unique_id",
                                (snprintf(addr_hex, 5, "%04X", node->unicast_addr), addr_hex));
        // Eindeutige ID mit Suffix
        char uid[32]; snprintf(uid, sizeof(uid), "steinel_%04X_light", node->unicast_addr);
        cJSON_AddStringToObject(root, "unique_id", uid);
        cJSON_AddStringToObject(root, "schema", "json");
        cJSON_AddStringToObject(root, "state_topic", state_topic);
        cJSON_AddStringToObject(root, "command_topic", cmd_topic);
        cJSON_AddBoolToObject  (root, "brightness", true);
        cJSON_AddNumberToObject(root, "brightness_scale", 100);
        cJSON_AddStringToObject(root, "payload_on", "ON");
        cJSON_AddStringToObject(root, "payload_off", "OFF");

        // Gerät-Info (alle Entities unter einem Gerät gruppieren)
        cJSON *dev = cJSON_AddObjectToObject(root, "device");
        cJSON *ids = cJSON_AddArrayToObject(dev, "identifiers");
        char dev_id[32]; snprintf(dev_id, sizeof(dev_id), "steinel_%04X", node->unicast_addr);
        cJSON_AddItemToArray(ids, cJSON_CreateString(dev_id));
        cJSON_AddStringToObject(dev, "name", node->name);
        cJSON_AddStringToObject(dev, "model", "L 810 SC");
        cJSON_AddStringToObject(dev, "manufacturer", "Steinel");
        cJSON_AddStringToObject(dev, "sw_version", "BLE Mesh 1.1");
        cJSON_AddStringToObject(dev, "via_device", "steinel_mesh_bridge");

        char *payload = cJSON_PrintUnformatted(root);
        esp_mqtt_client_publish(s_client, disc_topic, payload, 0, 1, 1);
        cJSON_Delete(root);
        free(payload);
        ESP_LOGI(TAG, "Discovery: Licht %s", node->name);
    }

    // ── 2. Bewegungsmelder ────────────────────────────────────────────────────
    {
        char disc_topic[128], state_topic[80];
        make_ha_discovery_topic(disc_topic, sizeof(disc_topic),
                                "binary_sensor", addr_hex, "motion");
        make_topic(state_topic, sizeof(state_topic), addr_hex, "motion/state");

        cJSON *root = cJSON_CreateObject();
        char uid[32]; snprintf(uid, sizeof(uid), "steinel_%04X_motion", node->unicast_addr);
        cJSON_AddStringToObject(root, "unique_id", uid);
        char motion_name[48]; snprintf(motion_name, sizeof(motion_name),
                                       "%s Bewegung", node->name);
        cJSON_AddStringToObject(root, "name", motion_name);
        cJSON_AddStringToObject(root, "device_class", "motion");
        cJSON_AddStringToObject(root, "state_topic", state_topic);
        cJSON_AddStringToObject(root, "payload_on",  "ON");
        cJSON_AddStringToObject(root, "payload_off", "OFF");

        cJSON *dev = cJSON_AddObjectToObject(root, "device");
        cJSON *ids = cJSON_AddArrayToObject(dev, "identifiers");
        char dev_id[32]; snprintf(dev_id, sizeof(dev_id), "steinel_%04X", node->unicast_addr);
        cJSON_AddItemToArray(ids, cJSON_CreateString(dev_id));

        char *payload = cJSON_PrintUnformatted(root);
        esp_mqtt_client_publish(s_client, disc_topic, payload, 0, 1, 1);
        cJSON_Delete(root);
        free(payload);
    }

    // ── 3. Beleuchtungsstärke ─────────────────────────────────────────────────
    {
        char disc_topic[128], state_topic[80];
        make_ha_discovery_topic(disc_topic, sizeof(disc_topic),
                                "sensor", addr_hex, "illuminance");
        make_topic(state_topic, sizeof(state_topic), addr_hex, "illuminance/state");

        cJSON *root = cJSON_CreateObject();
        char uid[32]; snprintf(uid, sizeof(uid), "steinel_%04X_lux", node->unicast_addr);
        cJSON_AddStringToObject(root, "unique_id", uid);
        char lux_name[48]; snprintf(lux_name, sizeof(lux_name),
                                    "%s Helligkeit", node->name);
        cJSON_AddStringToObject(root, "name", lux_name);
        cJSON_AddStringToObject(root, "device_class", "illuminance");
        cJSON_AddStringToObject(root, "state_topic", state_topic);
        cJSON_AddStringToObject(root, "unit_of_measurement", "lx");

        cJSON *dev = cJSON_AddObjectToObject(root, "device");
        cJSON *ids = cJSON_AddArrayToObject(dev, "identifiers");
        char dev_id[32]; snprintf(dev_id, sizeof(dev_id), "steinel_%04X", node->unicast_addr);
        cJSON_AddItemToArray(ids, cJSON_CreateString(dev_id));

        char *payload = cJSON_PrintUnformatted(root);
        esp_mqtt_client_publish(s_client, disc_topic, payload, 0, 1, 1);
        cJSON_Delete(root);
        free(payload);
    }

    // ── 4. Modus-Auswahl (Auto / Dauerlicht / Aus) ────────────────────────────
    {
        char disc_topic[128], state_topic[80], cmd_topic[80];
        make_ha_discovery_topic(disc_topic, sizeof(disc_topic),
                                "select", addr_hex, "mode");
        make_topic(state_topic, sizeof(state_topic), addr_hex, "mode/state");
        make_topic(cmd_topic,   sizeof(cmd_topic),   addr_hex, "mode/set");

        cJSON *root = cJSON_CreateObject();
        char uid[32]; snprintf(uid, sizeof(uid), "steinel_%04X_mode", node->unicast_addr);
        cJSON_AddStringToObject(root, "unique_id", uid);
        char mode_name[48]; snprintf(mode_name, sizeof(mode_name),
                                     "%s Modus", node->name);
        cJSON_AddStringToObject(root, "name", mode_name);
        cJSON_AddStringToObject(root, "state_topic",   state_topic);
        cJSON_AddStringToObject(root, "command_topic", cmd_topic);
        cJSON_AddStringToObject(root, "icon", "mdi:lightbulb-auto");

        cJSON *opts = cJSON_AddArrayToObject(root, "options");
        cJSON_AddItemToArray(opts, cJSON_CreateString("Auto"));
        cJSON_AddItemToArray(opts, cJSON_CreateString("Dauerlicht"));
        cJSON_AddItemToArray(opts, cJSON_CreateString("Deaktiviert"));

        cJSON *dev = cJSON_AddObjectToObject(root, "device");
        cJSON *ids = cJSON_AddArrayToObject(dev, "identifiers");
        char dev_id[32]; snprintf(dev_id, sizeof(dev_id), "steinel_%04X", node->unicast_addr);
        cJSON_AddItemToArray(ids, cJSON_CreateString(dev_id));

        char *payload = cJSON_PrintUnformatted(root);
        esp_mqtt_client_publish(s_client, disc_topic, payload, 0, 1, 1);
        cJSON_Delete(root);
        free(payload);
    }

    // ── 5. Nachlaufzeit (Number) ──────────────────────────────────────────────
    {
        char disc_topic[128], state_topic[80], cmd_topic[80];
        make_ha_discovery_topic(disc_topic, sizeof(disc_topic),
                                "number", addr_hex, "hold_time");
        make_topic(state_topic, sizeof(state_topic), addr_hex, "hold_time/state");
        make_topic(cmd_topic,   sizeof(cmd_topic),   addr_hex, "hold_time/set");

        cJSON *root = cJSON_CreateObject();
        char uid[32]; snprintf(uid, sizeof(uid), "steinel_%04X_hold", node->unicast_addr);
        cJSON_AddStringToObject(root, "unique_id", uid);
        char name[64]; snprintf(name, sizeof(name), "%s Nachlaufzeit", node->name);
        cJSON_AddStringToObject(root, "name", name);
        cJSON_AddStringToObject(root, "state_topic",   state_topic);
        cJSON_AddStringToObject(root, "command_topic", cmd_topic);
        cJSON_AddStringToObject(root, "unit_of_measurement", "s");
        cJSON_AddStringToObject(root, "icon", "mdi:timer-outline");
        cJSON_AddNumberToObject(root, "min", 5);
        cJSON_AddNumberToObject(root, "max", 3600);
        cJSON_AddNumberToObject(root, "step", 5);
        cJSON_AddNumberToObject(root, "mode", 0);  // slider

        cJSON *dev = cJSON_AddObjectToObject(root, "device");
        cJSON *ids = cJSON_AddArrayToObject(dev, "identifiers");
        char dev_id[32]; snprintf(dev_id, sizeof(dev_id), "steinel_%04X", node->unicast_addr);
        cJSON_AddItemToArray(ids, cJSON_CreateString(dev_id));

        char *payload = cJSON_PrintUnformatted(root);
        esp_mqtt_client_publish(s_client, disc_topic, payload, 0, 1, 1);
        cJSON_Delete(root);
        free(payload);
    }

    // ── 6. Empfindlichkeit (Select) ───────────────────────────────────────────
    {
        char disc_topic[128], state_topic[80], cmd_topic[80];
        make_ha_discovery_topic(disc_topic, sizeof(disc_topic),
                                "select", addr_hex, "sensitivity");
        make_topic(state_topic, sizeof(state_topic), addr_hex, "sensitivity/state");
        make_topic(cmd_topic,   sizeof(cmd_topic),   addr_hex, "sensitivity/set");

        cJSON *root = cJSON_CreateObject();
        char uid[32]; snprintf(uid, sizeof(uid), "steinel_%04X_sens", node->unicast_addr);
        cJSON_AddStringToObject(root, "unique_id", uid);
        char name[64]; snprintf(name, sizeof(name), "%s Empfindlichkeit", node->name);
        cJSON_AddStringToObject(root, "name", name);
        cJSON_AddStringToObject(root, "state_topic",   state_topic);
        cJSON_AddStringToObject(root, "command_topic", cmd_topic);
        cJSON_AddStringToObject(root, "icon", "mdi:radar");

        cJSON *opts = cJSON_AddArrayToObject(root, "options");
        cJSON_AddItemToArray(opts, cJSON_CreateString("Niedrig"));
        cJSON_AddItemToArray(opts, cJSON_CreateString("Mittel"));
        cJSON_AddItemToArray(opts, cJSON_CreateString("Hoch"));

        cJSON *dev = cJSON_AddObjectToObject(root, "device");
        cJSON *ids = cJSON_AddArrayToObject(dev, "identifiers");
        char dev_id[32]; snprintf(dev_id, sizeof(dev_id), "steinel_%04X", node->unicast_addr);
        cJSON_AddItemToArray(ids, cJSON_CreateString(dev_id));

        char *payload = cJSON_PrintUnformatted(root);
        esp_mqtt_client_publish(s_client, disc_topic, payload, 0, 1, 1);
        cJSON_Delete(root);
        free(payload);
    }

    // ── 7. Dämmerungsschwelle (Number) ────────────────────────────────────────
    {
        char disc_topic[128], state_topic[80], cmd_topic[80];
        make_ha_discovery_topic(disc_topic, sizeof(disc_topic),
                                "number", addr_hex, "twilight");
        make_topic(state_topic, sizeof(state_topic), addr_hex, "twilight/state");
        make_topic(cmd_topic,   sizeof(cmd_topic),   addr_hex, "twilight/set");

        cJSON *root = cJSON_CreateObject();
        char uid[32]; snprintf(uid, sizeof(uid), "steinel_%04X_twi", node->unicast_addr);
        cJSON_AddStringToObject(root, "unique_id", uid);
        char name[64]; snprintf(name, sizeof(name), "%s Dämmerungsschwelle", node->name);
        cJSON_AddStringToObject(root, "name", name);
        cJSON_AddStringToObject(root, "state_topic",   state_topic);
        cJSON_AddStringToObject(root, "command_topic", cmd_topic);
        cJSON_AddStringToObject(root, "unit_of_measurement", "lx");
        cJSON_AddStringToObject(root, "device_class", "illuminance");
        cJSON_AddStringToObject(root, "icon", "mdi:weather-sunset");
        cJSON_AddNumberToObject(root, "min", 1);
        cJSON_AddNumberToObject(root, "max", 2000);
        cJSON_AddNumberToObject(root, "step", 1);

        cJSON *dev = cJSON_AddObjectToObject(root, "device");
        cJSON *ids = cJSON_AddArrayToObject(dev, "identifiers");
        char dev_id[32]; snprintf(dev_id, sizeof(dev_id), "steinel_%04X", node->unicast_addr);
        cJSON_AddItemToArray(ids, cJSON_CreateString(dev_id));

        char *payload = cJSON_PrintUnformatted(root);
        esp_mqtt_client_publish(s_client, disc_topic, payload, 0, 1, 1);
        cJSON_Delete(root);
        free(payload);
    }

    // ── 8. Grundlicht-Level (Number) ─────────────────────────────────────────
    {
        char disc_topic[128], state_topic[80], cmd_topic[80];
        make_ha_discovery_topic(disc_topic, sizeof(disc_topic),
                                "number", addr_hex, "base_light");
        make_topic(state_topic, sizeof(state_topic), addr_hex, "base_light/state");
        make_topic(cmd_topic,   sizeof(cmd_topic),   addr_hex, "base_light/set");

        cJSON *root = cJSON_CreateObject();
        char uid[32]; snprintf(uid, sizeof(uid), "steinel_%04X_base", node->unicast_addr);
        cJSON_AddStringToObject(root, "unique_id", uid);
        char name[64]; snprintf(name, sizeof(name), "%s Grundlicht", node->name);
        cJSON_AddStringToObject(root, "name", name);
        cJSON_AddStringToObject(root, "state_topic",   state_topic);
        cJSON_AddStringToObject(root, "command_topic", cmd_topic);
        cJSON_AddStringToObject(root, "unit_of_measurement", "%");
        cJSON_AddStringToObject(root, "icon", "mdi:brightness-5");
        cJSON_AddNumberToObject(root, "min", 0);
        cJSON_AddNumberToObject(root, "max", 100);
        cJSON_AddNumberToObject(root, "step", 1);

        cJSON *dev = cJSON_AddObjectToObject(root, "device");
        cJSON *ids = cJSON_AddArrayToObject(dev, "identifiers");
        char dev_id[32]; snprintf(dev_id, sizeof(dev_id), "steinel_%04X", node->unicast_addr);
        cJSON_AddItemToArray(ids, cJSON_CreateString(dev_id));

        char *payload = cJSON_PrintUnformatted(root);
        esp_mqtt_client_publish(s_client, disc_topic, payload, 0, 1, 1);
        cJSON_Delete(root);
        free(payload);
    }

    ESP_LOGI(TAG, "✅ HA Discovery für %s (0x%04X) veröffentlicht",
             node->name, node->unicast_addr);
}

// ─── Zustände veröffentlichen ─────────────────────────────────────────────────
static void publish_node_state(const steinel_node_t *node)
{
    char addr_hex[5];
    addr_to_hex(node->unicast_addr, addr_hex);

    char topic[80];
    char buf[64];

    // Lichtstatus (JSON: {"state":"ON","brightness":80})
    make_topic(topic, sizeof(topic), addr_hex, "light/state");
    {
        int brightness_pct = node->lightness * 100 / 65535;
        snprintf(buf, sizeof(buf), "{\"state\":\"%s\",\"brightness\":%d}",
                 node->onoff_state ? "ON" : "OFF", brightness_pct);
        esp_mqtt_client_publish(s_client, topic, buf, 0, 1, 1);
    }

    // Bewegung
    make_topic(topic, sizeof(topic), addr_hex, "motion/state");
    esp_mqtt_client_publish(s_client, topic,
                            node->motion_detected ? "ON" : "OFF", 0, 1, 1);

    // Lux
    make_topic(topic, sizeof(topic), addr_hex, "illuminance/state");
    snprintf(buf, sizeof(buf), "%.1f", node->illuminance_lux);
    esp_mqtt_client_publish(s_client, topic, buf, 0, 1, 1);

    // Modus
    make_topic(topic, sizeof(topic), addr_hex, "mode/state");
    const char *mode_str = (node->continuous_mode) ? "Dauerlicht" :
                           (node->scene_number == 3) ? "Deaktiviert" : "Auto";
    esp_mqtt_client_publish(s_client, topic, mode_str, 0, 1, 1);

    // Nachlaufzeit
    make_topic(topic, sizeof(topic), addr_hex, "hold_time/state");
    snprintf(buf, sizeof(buf), "%lu", (unsigned long)node->hold_time_s);
    esp_mqtt_client_publish(s_client, topic, buf, 0, 1, 1);

    // Empfindlichkeit
    make_topic(topic, sizeof(topic), addr_hex, "sensitivity/state");
    const char *sens_str[] = {"Niedrig", "Mittel", "Hoch"};
    esp_mqtt_client_publish(s_client, topic,
                            sens_str[node->sensitivity < 3 ? node->sensitivity : 1],
                            0, 1, 1);

    // Dämmerungsschwelle
    make_topic(topic, sizeof(topic), addr_hex, "twilight/state");
    snprintf(buf, sizeof(buf), "%u", node->twilight_lux);
    esp_mqtt_client_publish(s_client, topic, buf, 0, 1, 1);

    // Grundlicht
    make_topic(topic, sizeof(topic), addr_hex, "base_light/state");
    snprintf(buf, sizeof(buf), "%u", node->base_lightness * 100 / 65535);
    esp_mqtt_client_publish(s_client, topic, buf, 0, 1, 1);
}

// ─── Eingehende MQTT-Befehle ──────────────────────────────────────────────────
static void handle_command(const char *topic, const char *data, int data_len)
{
    // Topic-Format: steinel_mesh/<ADDR_HEX>/<entity>/set
    // Parsen der Adresse aus dem Topic
    char t[128];
    strncpy(t, topic, sizeof(t)-1);

    char *base_end = strstr(t, MQTT_BASE_TOPIC "/");
    if (!base_end) return;
    base_end += strlen(MQTT_BASE_TOPIC "/");

    // Adresse (4 Hex-Zeichen)
    char addr_str[5] = {0};
    strncpy(addr_str, base_end, 4);
    uint16_t addr = (uint16_t)strtol(addr_str, NULL, 16);
    if (addr == 0) return;

    // Suffix nach der Adresse
    const char *suffix = base_end + 5;  // +5: "XXXX/"

    char payload[128];
    snprintf(payload, sizeof(payload), "%.*s", data_len, data);
    ESP_LOGI(TAG, "CMD → 0x%04X [%s] = %s", addr, suffix, payload);

    if (strcmp(suffix, "light/set") == 0) {
        // JSON payload: {"state":"ON"} oder {"state":"ON","brightness":75}
        cJSON *json = cJSON_Parse(payload);
        if (json) {
            cJSON *state = cJSON_GetObjectItem(json, "state");
            cJSON *bri   = cJSON_GetObjectItem(json, "brightness");
            if (state) {
                bool on = strcmp(state->valuestring, "ON") == 0;
                steinel_set_onoff(addr, on);
            }
            if (bri) {
                uint16_t lightness = (uint16_t)(bri->valuedouble * 65535 / 100);
                steinel_set_lightness(addr, lightness);
            }
            cJSON_Delete(json);
        }
    }
    else if (strcmp(suffix, "mode/set") == 0) {
        if (strcmp(payload, "Dauerlicht") == 0) {
            steinel_set_continuous_mode(addr, true);
        } else if (strcmp(payload, "Deaktiviert") == 0) {
            steinel_recall_scene(addr, 3);
        } else {  // Auto
            steinel_set_continuous_mode(addr, false);
        }
    }
    else if (strcmp(suffix, "hold_time/set") == 0) {
        uint32_t secs = (uint32_t)atoi(payload);
        steinel_set_hold_time(addr, secs);
    }
    else if (strcmp(suffix, "sensitivity/set") == 0) {
        uint8_t level = 1;
        if (strcmp(payload, "Niedrig") == 0)  level = 0;
        else if (strcmp(payload, "Hoch") == 0) level = 2;
        steinel_set_sensitivity(addr, level);
    }
    else if (strcmp(suffix, "twilight/set") == 0) {
        uint16_t lux = (uint16_t)atoi(payload);
        steinel_set_twilight_threshold(addr, lux);
    }
    else if (strcmp(suffix, "base_light/set") == 0) {
        uint8_t pct = (uint8_t)atoi(payload);
        uint16_t level = pct * 65535 / 100;
        steinel_set_base_lightness(addr, level);
    }
}

// ─── Subscriptions nach MQTT-Verbindung ──────────────────────────────────────
static void subscribe_commands(void)
{
    // Alle Befehlstopics für alle Knoten abonnieren (Wildcard)
    esp_mqtt_client_subscribe(s_client, MQTT_BASE_TOPIC "/+/light/set",      1);
    esp_mqtt_client_subscribe(s_client, MQTT_BASE_TOPIC "/+/mode/set",       1);
    esp_mqtt_client_subscribe(s_client, MQTT_BASE_TOPIC "/+/hold_time/set",  1);
    esp_mqtt_client_subscribe(s_client, MQTT_BASE_TOPIC "/+/sensitivity/set",1);
    esp_mqtt_client_subscribe(s_client, MQTT_BASE_TOPIC "/+/twilight/set",   1);
    esp_mqtt_client_subscribe(s_client, MQTT_BASE_TOPIC "/+/base_light/set", 1);
    ESP_LOGI(TAG, "MQTT Subscriptions gesetzt");
}

// ─── MQTT Event Handler ───────────────────────────────────────────────────────
static void mqtt_event_handler(void *arg, esp_event_base_t base,
                                int32_t event_id, void *event_data)
{
    esp_mqtt_event_handle_t event = (esp_mqtt_event_handle_t)event_data;

    switch ((esp_mqtt_event_id_t)event_id) {
    case MQTT_EVENT_CONNECTED:
        ESP_LOGI(TAG, "✅ MQTT verbunden");
        subscribe_commands();
        // Bestehende Knoten erneut ankündigen
        for (int i = 0; i < ble_mesh_get_node_count(); i++) {
            const steinel_node_t *n = ble_mesh_get_node(i);
            if (n && n->active) {
                publish_ha_discovery(n);
                publish_node_state(n);
            }
        }
        break;

    case MQTT_EVENT_DISCONNECTED:
        ESP_LOGW(TAG, "MQTT getrennt – verbinde erneut...");
        break;

    case MQTT_EVENT_DATA:
        handle_command(event->topic, event->data, event->data_len);
        break;

    case MQTT_EVENT_ERROR:
        ESP_LOGE(TAG, "MQTT Fehler");
        break;

    default:
        break;
    }
}

// ─── Bridge-Callbacks (von BLE Mesh aufgerufen) ───────────────────────────────
void mqtt_bridge_on_node_added(const steinel_node_t *node)
{
    if (!s_client) return;
    publish_ha_discovery(node);
    publish_node_state(node);
}

void mqtt_bridge_on_state_changed(const steinel_node_t *node)
{
    if (!s_client) return;
    publish_node_state(node);
}

// ─── Initialisierung ──────────────────────────────────────────────────────────
esp_err_t mqtt_bridge_init(const mqtt_bridge_config_t *cfg)
{
    esp_mqtt_client_config_t mqtt_cfg = {
        .broker.address.uri = cfg->broker_url,
        .credentials.client_id = cfg->client_id,
    };
    if (cfg->username && strlen(cfg->username) > 0) {
        mqtt_cfg.credentials.username = cfg->username;
        mqtt_cfg.credentials.authentication.password = cfg->password;
    }

    // LWT: Bridge offline-Status melden
    mqtt_cfg.session.last_will.topic  = MQTT_BASE_TOPIC "/bridge/status";
    mqtt_cfg.session.last_will.msg    = "offline";
    mqtt_cfg.session.last_will.qos    = 1;
    mqtt_cfg.session.last_will.retain = 1;

    s_client = esp_mqtt_client_init(&mqtt_cfg);
    if (!s_client) return ESP_FAIL;

    esp_mqtt_client_register_event(s_client, ESP_EVENT_ANY_ID,
                                   mqtt_event_handler, NULL);
    esp_err_t err = esp_mqtt_client_start(s_client);
    if (err != ESP_OK) return err;

    // BLE-Mesh-Callbacks registrieren
    ble_mesh_register_callbacks(mqtt_bridge_on_node_added,
                                mqtt_bridge_on_state_changed);

    // Online-Status veröffentlichen
    esp_mqtt_client_publish(s_client,
                            MQTT_BASE_TOPIC "/bridge/status",
                            "online", 0, 1, 1);

    ESP_LOGI(TAG, "MQTT Bridge initialisiert → %s", cfg->broker_url);
    return ESP_OK;
}
