#pragma once
#include "esp_err.h"

typedef struct {
    const char *ssid;
    const char *password;
} wifi_manager_config_t;

esp_err_t wifi_manager_init(const wifi_manager_config_t *config);
void      wifi_manager_wait_connected(void);
bool      wifi_manager_is_connected(void);
