/**
 * Steinel BLE Mesh ↔ Home Assistant Bridge
 * ESP32 Provisioner + MQTT Gateway
 *
 * Architektur:
 *   Steinel L 810 SC  ──BLE Mesh──►  ESP32  ──WiFi/MQTT──►  Home Assistant
 *
 * Lizenz: MIT
 */

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_log.h"
#include "nvs_flash.h"

#include "wifi_manager.h"
#include "ble_mesh.h"
#include "mqtt_bridge.h"

static const char *TAG = "STEINEL_MAIN";

// ────────────────────────────────────────────────────────────────────────────
// Konfiguration – bitte in menuconfig (idf.py menuconfig) anpassen oder
// direkt hier eintragen
// ────────────────────────────────────────────────────────────────────────────
#ifndef CONFIG_WIFI_SSID
#define CONFIG_WIFI_SSID      "DeinWLAN"
#endif
#ifndef CONFIG_WIFI_PASSWORD
#define CONFIG_WIFI_PASSWORD  "DeinPasswort"
#endif
#ifndef CONFIG_MQTT_BROKER_URL
#define CONFIG_MQTT_BROKER_URL "mqtt://192.168.1.10:1883"
#endif
#ifndef CONFIG_MQTT_USERNAME
#define CONFIG_MQTT_USERNAME  ""
#endif
#ifndef CONFIG_MQTT_PASSWORD
#define CONFIG_MQTT_PASSWORD  ""
#endif

void app_main(void)
{
    ESP_LOGI(TAG, "=== Steinel BLE Mesh → Home Assistant Bridge ===");
    ESP_LOGI(TAG, "Firmware Version: 1.0.0");

    // NVS für WiFi-Credentials und Mesh-Provisioning-Daten
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    // WiFi initialisieren und verbinden
    wifi_manager_config_t wifi_cfg = {
        .ssid     = CONFIG_WIFI_SSID,
        .password = CONFIG_WIFI_PASSWORD,
    };
    ESP_ERROR_CHECK(wifi_manager_init(&wifi_cfg));
    ESP_LOGI(TAG, "Warte auf WiFi-Verbindung...");
    wifi_manager_wait_connected();
    ESP_LOGI(TAG, "WiFi verbunden");

    // MQTT-Bridge initialisieren (verbindet sich mit HA-Broker)
    mqtt_bridge_config_t mqtt_cfg = {
        .broker_url = CONFIG_MQTT_BROKER_URL,
        .username   = CONFIG_MQTT_USERNAME,
        .password   = CONFIG_MQTT_PASSWORD,
        .client_id  = "steinel_mesh_bridge",
    };
    ESP_ERROR_CHECK(mqtt_bridge_init(&mqtt_cfg));

    // BLE Mesh Provisioner initialisieren
    ESP_ERROR_CHECK(ble_mesh_init());
    ESP_LOGI(TAG, "BLE Mesh Provisioner gestartet – scanne nach Steinel-Geräten...");

    // Hauptschleife: Statusmeldung alle 60 Sekunden
    while (1) {
        ESP_LOGI(TAG, "Aktive Steinel-Knoten: %d", ble_mesh_get_node_count());
        vTaskDelay(pdMS_TO_TICKS(60000));
    }
}
