#pragma once
#include "esp_err.h"
#include <stdint.h>
#include <stdbool.h>

// ─── BLE Mesh Modell-IDs (SIG Standard) ────────────────────────────────────
#define BLE_MESH_MODEL_ID_GEN_ONOFF_CLI     0x1001
#define BLE_MESH_MODEL_ID_GEN_LEVEL_CLI     0x1003
#define BLE_MESH_MODEL_ID_LIGHT_LIGHTNESS_CLI 0x1302
#define BLE_MESH_MODEL_ID_SENSOR_CLI        0x1102
#define BLE_MESH_MODEL_ID_SCENE_CLI         0x1205
#define BLE_MESH_MODEL_ID_SCHEDULER_CLI     0x1208
#define BLE_MESH_MODEL_ID_GEN_DTT_CLI       0x1005  // Default Transition Time

// ─── Sensor Property IDs (BLE Mesh Device Properties Spec) ─────────────────
#define SENSOR_PROP_MOTION_SENSED           0x004F
#define SENSOR_PROP_AMBIENT_LIGHT_LEVEL     0x004E  // lux
#define SENSOR_PROP_OCCUPANCY               0x004C
#define SENSOR_PROP_TIME_SINCE_MOTION       0x0068

// ─── Steinel-spezifische Werte ───────────────────────────────────────────────
// Die L 810 SC arbeitet mit Standard BLE Mesh SIG v1.1.
// Vendor-Modell-ID (Hersteller-spezifisch, experimentell):
#define STEINEL_COMPANY_ID                  0x0689   // Bluetooth SIG Company ID
#define STEINEL_VENDOR_MODEL_ID             0x0001   // experimentell

// Maximale Anzahl verwaltbarer Steinel-Knoten
#define STEINEL_MAX_NODES                   16

// ─── Knotenstatus ────────────────────────────────────────────────────────────
typedef struct {
    bool     active;
    uint16_t unicast_addr;         // Mesh-Adresse nach Provisioning
    char     device_uuid[37];      // UUID als String (für MQTT-Topic)
    char     name[32];             // Anzeigename
    bool     onoff_state;          // Licht an/aus
    uint16_t lightness;            // Helligkeit 0–65535
    uint16_t base_lightness;       // Grundlicht-Level 0–65535
    float    illuminance_lux;      // aktueller Lichtwert
    bool     motion_detected;      // Bewegung erkannt
    uint32_t hold_time_s;          // Nachlaufzeit in Sekunden
    uint8_t  sensitivity;          // Empfindlichkeit 0=low,1=mid,2=high
    uint16_t twilight_lux;         // Dämmerungsschwelle
    bool     continuous_mode;      // Dauerlicht aktiv
    uint8_t  scene_number;         // aktive Szene (1=auto,2=dauerlicht,3=aus)
} steinel_node_t;

// ─── Callbacks ───────────────────────────────────────────────────────────────
/** Wird aufgerufen, wenn ein neues Steinel-Gerät provisioniert wurde */
typedef void (*steinel_node_added_cb_t)(const steinel_node_t *node);

/** Wird aufgerufen, wenn sich ein Zustand ändert (Licht, Sensor) */
typedef void (*steinel_state_changed_cb_t)(const steinel_node_t *node);

// ─── Public API ──────────────────────────────────────────────────────────────
esp_err_t ble_mesh_init(void);
void      ble_mesh_register_callbacks(steinel_node_added_cb_t on_added,
                                       steinel_state_changed_cb_t on_changed);

int       ble_mesh_get_node_count(void);
const steinel_node_t *ble_mesh_get_node(int index);
const steinel_node_t *ble_mesh_find_node_by_addr(uint16_t addr);

// Lichtsteuerung
esp_err_t steinel_set_onoff(uint16_t unicast_addr, bool on);
esp_err_t steinel_set_lightness(uint16_t unicast_addr, uint16_t lightness_0_65535);
esp_err_t steinel_set_base_lightness(uint16_t unicast_addr, uint16_t level);
esp_err_t steinel_set_continuous_mode(uint16_t unicast_addr, bool continuous);
esp_err_t steinel_set_transition_time_ms(uint16_t unicast_addr, uint32_t ms);

// Sensor-Konfiguration
esp_err_t steinel_set_hold_time(uint16_t unicast_addr, uint32_t seconds);
esp_err_t steinel_set_sensitivity(uint16_t unicast_addr, uint8_t level);
esp_err_t steinel_set_twilight_threshold(uint16_t unicast_addr, uint16_t lux);

// Szenen (1=auto, 2=dauerlicht, 3=deaktiviert)
esp_err_t steinel_recall_scene(uint16_t unicast_addr, uint8_t scene_number);
esp_err_t steinel_store_scene(uint16_t unicast_addr, uint8_t scene_number);

// Scheduler (Zeitplan)
esp_err_t steinel_set_schedule(uint16_t unicast_addr,
                                uint8_t  entry_index,    // 0–15
                                uint8_t  hour,           // 0–23
                                uint8_t  minute,         // 0–59
                                uint8_t  action,         // 0=off,1=on,2=scene
                                uint8_t  scene_number);

// Sensordaten aktiv abfragen
esp_err_t steinel_request_sensor_data(uint16_t unicast_addr);
