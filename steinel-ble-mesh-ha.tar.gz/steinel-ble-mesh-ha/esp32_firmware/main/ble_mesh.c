/**
 * ble_mesh.c  –  ESP32 BLE Mesh Provisioner für Steinel L 810 SC
 *
 * Implementiert:
 *  - BLE Mesh Provisioner (provisioniert Steinel-Geräte ins Mesh)
 *  - Generic OnOff Client  (Licht an/aus)
 *  - Generic Level Client  (Helligkeit)
 *  - Light Lightness Client (Dimmen)
 *  - Sensor Client         (Bewegung, Lux)
 *  - Scene Client          (Szenen / Dauerlicht)
 *  - Scheduler Client      (Zeitplan)
 *  - Generic Default Transition Time (Softlichtstart)
 */

#include "ble_mesh.h"

#include "esp_log.h"
#include "esp_ble_mesh_defs.h"
#include "esp_ble_mesh_common_api.h"
#include "esp_ble_mesh_provisioning_api.h"
#include "esp_ble_mesh_networking_api.h"
#include "esp_ble_mesh_config_model_api.h"
#include "esp_ble_mesh_generic_model_api.h"
#include "esp_ble_mesh_sensor_model_api.h"
#include "esp_ble_mesh_scene_model_api.h"
#include "esp_ble_mesh_time_scene_model_api.h"
#include "esp_ble_mesh_lighting_model_api.h"

#include <string.h>
#include <stdlib.h>

static const char *TAG = "BLE_MESH";

// ─── Netzwerk-Keys ───────────────────────────────────────────────────────────
// WICHTIG: In der Produktion per menuconfig oder NVS konfigurieren!
static uint8_t s_net_key[16]  = {
    0x00,0x23,0x45,0x67, 0x89,0xAB,0xCD,0xEF,
    0x01,0x23,0x45,0x67, 0x89,0xAB,0xCD,0xEF
};
static uint8_t s_app_key[16]  = {
    0xAA,0xBB,0xCC,0xDD, 0xEE,0xFF,0x11,0x22,
    0x33,0x44,0x55,0x66, 0x77,0x88,0x99,0x00
};
static uint16_t s_net_idx  = 0;
static uint16_t s_app_idx  = 0;
static uint8_t  s_prov_tid = 0;  // Transaction ID Counter

// ─── Knotenliste ─────────────────────────────────────────────────────────────
static steinel_node_t s_nodes[STEINEL_MAX_NODES];
static int s_node_count = 0;

// ─── Callbacks (registriert von mqtt_bridge) ─────────────────────────────────
static steinel_node_added_cb_t   s_on_added   = NULL;
static steinel_state_changed_cb_t s_on_changed = NULL;

// ─── Provisioner-Konfiguration ────────────────────────────────────────────────
static esp_ble_mesh_prov_t s_provision = {
    .uuid            = {0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
                        0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F},
    .output_size     = 0,
    .output_actions  = 0,
    .input_size      = 0,
    .input_actions   = 0,
};

// ─── Client-Model-Handles ────────────────────────────────────────────────────
static esp_ble_mesh_client_t s_onoff_client;
static esp_ble_mesh_client_t s_level_client;
static esp_ble_mesh_client_t s_lightness_client;
static esp_ble_mesh_client_t s_sensor_client;
static esp_ble_mesh_client_t s_scene_client;
static esp_ble_mesh_client_t s_dtt_client;

// Root-Element Modelle (Provisioner-Seite)
static esp_ble_mesh_model_t s_root_models[] = {
    ESP_BLE_MESH_MODEL_CFG_CLI(&s_onoff_client),          // Config Client
    ESP_BLE_MESH_MODEL_GEN_ONOFF_CLI(NULL, &s_onoff_client),
    ESP_BLE_MESH_MODEL_GEN_LEVEL_CLI(NULL, &s_level_client),
    ESP_BLE_MESH_MODEL_LIGHT_LIGHTNESS_CLI(NULL, &s_lightness_client),
    ESP_BLE_MESH_MODEL_SENSOR_CLI(NULL, &s_sensor_client),
    ESP_BLE_MESH_MODEL_SCENE_CLI(NULL, &s_scene_client),
    ESP_BLE_MESH_MODEL_GEN_DEF_TRANS_TIME_CLI(NULL, &s_dtt_client),
};

static esp_ble_mesh_elem_t s_elements[] = {
    ESP_BLE_MESH_ELEMENT(0, s_root_models, ESP_BLE_MESH_MODEL_NONE),
};

static esp_ble_mesh_comp_t s_composition = {
    .cid        = 0x02E5,  // Espressif Company ID
    .pid        = 0x0001,
    .vid        = 0x0001,
    .element_count = ARRAY_SIZE(s_elements),
    .elements      = s_elements,
};

// ─── Hilfsfunktionen ─────────────────────────────────────────────────────────
static void uuid_to_str(const uint8_t *uuid, char *buf)
{
    snprintf(buf, 37,
        "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
        uuid[0], uuid[1], uuid[2],  uuid[3],
        uuid[4], uuid[5],
        uuid[6], uuid[7],
        uuid[8], uuid[9],
        uuid[10],uuid[11],uuid[12],uuid[13],uuid[14],uuid[15]);
}

static steinel_node_t *find_or_create_node(uint16_t addr)
{
    for (int i = 0; i < s_node_count; i++) {
        if (s_nodes[i].unicast_addr == addr) return &s_nodes[i];
    }
    if (s_node_count < STEINEL_MAX_NODES) {
        steinel_node_t *n = &s_nodes[s_node_count++];
        memset(n, 0, sizeof(*n));
        n->active       = true;
        n->unicast_addr = addr;
        n->hold_time_s  = 300;   // Standard: 5 Minuten
        n->sensitivity  = 1;      // Mittel
        n->twilight_lux = 50;    // Standard: 50 lux
        n->base_lightness = 6554; // Grundlicht ~10 %
        snprintf(n->name, sizeof(n->name), "Steinel_%04X", addr);
        return n;
    }
    return NULL;
}

// ─── Config-Client: Modelle nach Provisioning konfigurieren ──────────────────
static void configure_node(uint16_t unicast_addr)
{
    ESP_LOGI(TAG, "Konfiguriere Knoten 0x%04X...", unicast_addr);

    // 1. App-Key an den Knoten übertragen
    esp_ble_mesh_cfg_client_set_state_t set = {0};
    set.app_key_add.net_idx  = s_net_idx;
    set.app_key_add.app_idx  = s_app_idx;
    memcpy(set.app_key_add.app_key, s_app_key, 16);

    esp_ble_mesh_client_common_param_t param = {
        .opcode           = ESP_BLE_MESH_MODEL_OP_APP_KEY_ADD,
        .model            = s_root_models,  // Config Client
        .ctx.net_idx      = s_net_idx,
        .ctx.app_idx      = s_app_idx,
        .ctx.addr         = unicast_addr,
        .ctx.send_ttl     = 3,
        .msg_role         = ROLE_PROVISIONER,
        .msg_timeout      = 4000,
    };

    esp_ble_mesh_config_client_set_state(&param, &set);
    // Weitere Konfiguration erfolgt nach Erhalt der ACK im Event-Handler
}

// ─── Provisioning-Callback ────────────────────────────────────────────────────
static void prov_complete_handler(uint16_t node_index, const esp_ble_mesh_octet16_t uuid,
                                   uint16_t unicast_addr, uint8_t element_num, uint16_t net_idx)
{
    ESP_LOGI(TAG, "✅ Gerät provisioniert: Adresse=0x%04X, Elemente=%d",
             unicast_addr, element_num);

    steinel_node_t *node = find_or_create_node(unicast_addr);
    if (!node) {
        ESP_LOGE(TAG, "Knotenliste voll!");
        return;
    }

    uuid_to_str(uuid, node->device_uuid);
    ESP_LOGI(TAG, "   UUID: %s", node->device_uuid);

    // Verzögerte Konfiguration (App-Key binden, Modelle konfigurieren)
    vTaskDelay(pdMS_TO_TICKS(500));
    configure_node(unicast_addr);

    if (s_on_added) s_on_added(node);
}

static void ble_mesh_provisioning_cb(esp_ble_mesh_prov_cb_event_t event,
                                      esp_ble_mesh_prov_cb_param_t *param)
{
    switch (event) {
    case ESP_BLE_MESH_PROVISIONER_PROV_ENABLE_COMP_EVT:
        ESP_LOGI(TAG, "Provisioner aktiviert, scanne...");
        break;

    case ESP_BLE_MESH_PROVISIONER_RECV_UNPROV_ADV_PKT_EVT: {
        // Unversioniertes Gerät gefunden – automatisch provisionieren
        const uint8_t *uuid = param->provisioner_recv_unprov_adv_pkt.dev_uuid;
        uint8_t addr[6];
        memcpy(addr, param->provisioner_recv_unprov_adv_pkt.addr, 6);
        char uuid_str[37];
        uuid_to_str(uuid, uuid_str);
        ESP_LOGI(TAG, "Unversioniertes Gerät: UUID=%s", uuid_str);

        // Steinel-Geräte identifizieren (erste 2 Bytes des UUID prüfen)
        // Steinel verwendet spezifisches UUID-Präfix – hier als offen konfigurierbar
        esp_ble_mesh_unprov_dev_add_t dev = {0};
        memcpy(dev.uuid, uuid, 16);
        memcpy(dev.addr, addr, 6);
        dev.addr_type   = param->provisioner_recv_unprov_adv_pkt.addr_type;
        dev.oob_info    = param->provisioner_recv_unprov_adv_pkt.oob_info;
        dev.bearer      = param->provisioner_recv_unprov_adv_pkt.bearer;

        esp_ble_mesh_provisioner_add_unprov_dev(&dev,
            ADD_DEV_RM_AFTER_PROV_FLAG | ADD_DEV_START_PROV_NOW_FLAG |
            ADD_DEV_FLUSHABLE_DEV_FLAG);
        break;
    }

    case ESP_BLE_MESH_PROVISIONER_PROV_COMPLETE_EVT:
        prov_complete_handler(
            param->provisioner_prov_complete.node_idx,
            param->provisioner_prov_complete.device_uuid,
            param->provisioner_prov_complete.unicast_addr,
            param->provisioner_prov_complete.element_num,
            param->provisioner_prov_complete.netkey_idx);
        break;

    case ESP_BLE_MESH_PROVISIONER_PROV_LINK_CLOSE_EVT:
        ESP_LOGI(TAG, "Provisioning-Link geschlossen, Reason=0x%02X",
                 param->provisioner_prov_link_close.reason);
        break;

    default:
        break;
    }
}

// ─── Generic OnOff Client Callback ───────────────────────────────────────────
static void generic_client_cb(esp_ble_mesh_generic_client_cb_event_t event,
                               esp_ble_mesh_generic_client_cb_param_t *param)
{
    if (event == ESP_BLE_MESH_GENERIC_CLIENT_GET_STATE_EVT ||
        event == ESP_BLE_MESH_GENERIC_CLIENT_SET_STATE_EVT) {

        uint16_t addr = param->params->ctx.addr;
        steinel_node_t *node = find_or_create_node(addr);
        if (!node) return;

        switch (param->params->opcode) {
        case ESP_BLE_MESH_MODEL_OP_GEN_ONOFF_STATUS:
            node->onoff_state = param->status_cb.onoff_status.present_onoff;
            ESP_LOGI(TAG, "Licht 0x%04X: %s", addr,
                     node->onoff_state ? "AN" : "AUS");
            if (s_on_changed) s_on_changed(node);
            break;

        case ESP_BLE_MESH_MODEL_OP_GEN_LEVEL_STATUS:
            // Level -32768..32767, umrechnen auf 0..65535
            node->lightness = (uint16_t)(param->status_cb.level_status.present_level + 32768);
            ESP_LOGI(TAG, "Helligkeit 0x%04X: %d%%", addr,
                     node->lightness * 100 / 65535);
            if (s_on_changed) s_on_changed(node);
            break;

        default:
            break;
        }
    }
}

// ─── Sensor Client Callback ───────────────────────────────────────────────────
static void sensor_client_cb(esp_ble_mesh_sensor_client_cb_event_t event,
                              esp_ble_mesh_sensor_client_cb_param_t *param)
{
    if (event != ESP_BLE_MESH_SENSOR_CLIENT_GET_STATE_EVT &&
        event != ESP_BLE_MESH_SENSOR_CLIENT_PUBLISH_EVT) return;

    uint16_t addr = param->params->ctx.addr;
    steinel_node_t *node = find_or_create_node(addr);
    if (!node) return;

    // Sensor-Status auswerten (mehrere Properties möglich)
    esp_ble_mesh_sensor_data_t *data = param->status_cb.sensor_status.marshalled_sensor_data;
    if (!data) return;

    // Property-ID aus den Rohdaten lesen (BLE Mesh Sensor Format B)
    uint8_t *raw = data->raw_value->data;
    uint16_t prop_id = raw[0] | (raw[1] << 8);
    uint8_t  data_len = (raw[2] & 0x1F) + 1;  // MPID Format B
    uint8_t *value = &raw[3];

    switch (prop_id) {
    case SENSOR_PROP_MOTION_SENSED:
        // Wert 0–100 (Prozent der erkannten Bewegung)
        node->motion_detected = (value[0] > 0);
        ESP_LOGI(TAG, "Bewegung 0x%04X: %s (Wert=%d%%)",
                 addr, node->motion_detected ? "JA" : "NEIN", value[0]);
        if (s_on_changed) s_on_changed(node);
        break;

    case SENSOR_PROP_AMBIENT_LIGHT_LEVEL:
        // 3 Bytes, Einheit 0.01 lux per LSB
        if (data_len >= 3) {
            uint32_t raw_lux = value[0] | (value[1]<<8) | (value[2]<<16);
            node->illuminance_lux = raw_lux * 0.01f;
            ESP_LOGI(TAG, "Helligkeit 0x%04X: %.1f lux",
                     addr, node->illuminance_lux);
            if (s_on_changed) s_on_changed(node);
        }
        break;

    case SENSOR_PROP_TIME_SINCE_MOTION:
        // Sekunden seit letzter Bewegung (uint24)
        if (data_len >= 3) {
            uint32_t secs = value[0] | (value[1]<<8) | (value[2]<<16);
            node->motion_detected = (secs < 5);  // <5s → Bewegung aktiv
            ESP_LOGI(TAG, "Zeit seit Bewegung 0x%04X: %lus", addr,
                     (unsigned long)secs);
            if (s_on_changed) s_on_changed(node);
        }
        break;

    default:
        ESP_LOGD(TAG, "Unbekannte Property ID: 0x%04X", prop_id);
        break;
    }
}

// ─── Scene Client Callback ────────────────────────────────────────────────────
static void scene_client_cb(esp_ble_mesh_scene_client_cb_event_t event,
                             esp_ble_mesh_scene_client_cb_param_t *param)
{
    if (event == ESP_BLE_MESH_SCENE_CLIENT_SET_STATE_EVT) {
        uint16_t addr = param->params->ctx.addr;
        steinel_node_t *node = find_or_create_node(addr);
        if (!node) return;

        if (param->params->opcode == ESP_BLE_MESH_MODEL_OP_SCENE_STATUS) {
            node->scene_number = param->status_cb.scene_status.current_scene;
            node->continuous_mode = (node->scene_number == 2);
            if (s_on_changed) s_on_changed(node);
        }
    }
}

// ─── Config Client Callback (App-Key Binding) ─────────────────────────────────
static void config_client_cb(esp_ble_mesh_cfg_client_cb_event_t event,
                              esp_ble_mesh_cfg_client_cb_param_t *param)
{
    if (event != ESP_BLE_MESH_CFG_CLIENT_SET_STATE_EVT) return;
    uint16_t addr = param->params->ctx.addr;

    if (param->params->opcode == ESP_BLE_MESH_MODEL_OP_APP_KEY_STATUS) {
        ESP_LOGI(TAG, "App-Key an 0x%04X gebunden, binde jetzt Modelle...", addr);

        // Modelle an den App-Key binden (alle relevanten Modelle)
        uint16_t model_ids[] = {
            ESP_BLE_MESH_MODEL_ID_GEN_ONOFF_SRV,
            ESP_BLE_MESH_MODEL_ID_GEN_LEVEL_SRV,
            ESP_BLE_MESH_MODEL_ID_LIGHT_LIGHTNESS_SRV,
            ESP_BLE_MESH_MODEL_ID_SENSOR_SRV,
            ESP_BLE_MESH_MODEL_ID_SCENE_SRV,
            ESP_BLE_MESH_MODEL_ID_SCHEDULER_SRV,
            ESP_BLE_MESH_MODEL_ID_GEN_DEF_TRANS_TIME_SRV,
        };

        for (int i = 0; i < ARRAY_SIZE(model_ids); i++) {
            esp_ble_mesh_cfg_client_set_state_t set = {0};
            set.model_app_bind.element_addr  = addr;
            set.model_app_bind.model_app_idx = s_app_idx;
            set.model_app_bind.model_id      = model_ids[i];
            set.model_app_bind.company_id    = 0xFFFF;  // SIG-Modell

            esp_ble_mesh_client_common_param_t p = {
                .opcode       = ESP_BLE_MESH_MODEL_OP_MODEL_APP_BIND,
                .model        = s_root_models,
                .ctx.net_idx  = s_net_idx,
                .ctx.app_idx  = s_app_idx,
                .ctx.addr     = addr,
                .ctx.send_ttl = 3,
                .msg_role     = ROLE_PROVISIONER,
                .msg_timeout  = 4000,
            };
            esp_ble_mesh_config_client_set_state(&p, &set);
            vTaskDelay(pdMS_TO_TICKS(200));
        }

        // Sensor-Server zur automatischen Veröffentlichung konfigurieren
        // (Pub-Adresse = Gruppe 0xC000, damit der Provisioner alles empfängt)
        esp_ble_mesh_cfg_client_set_state_t pub_set = {0};
        pub_set.model_pub_set.element_addr  = addr;
        pub_set.model_pub_set.publish_addr  = 0xC000;  // Gruppen-Adresse
        pub_set.model_pub_set.publish_app_idx = s_app_idx;
        pub_set.model_pub_set.publish_ttl   = 3;
        pub_set.model_pub_set.publish_period = 0x43;  // ~10 Sekunden
        pub_set.model_pub_set.publish_retransmit = 0;
        pub_set.model_pub_set.model_id      = ESP_BLE_MESH_MODEL_ID_SENSOR_SRV;
        pub_set.model_pub_set.company_id    = 0xFFFF;

        esp_ble_mesh_client_common_param_t pp = {
            .opcode       = ESP_BLE_MESH_MODEL_OP_MODEL_PUB_SET,
            .model        = s_root_models,
            .ctx.net_idx  = s_net_idx,
            .ctx.app_idx  = s_app_idx,
            .ctx.addr     = addr,
            .ctx.send_ttl = 3,
            .msg_role     = ROLE_PROVISIONER,
            .msg_timeout  = 4000,
        };
        esp_ble_mesh_config_client_set_state(&pp, &pub_set);

        ESP_LOGI(TAG, "✅ Knoten 0x%04X vollständig konfiguriert", addr);
    }
}

// ─── Initialisierung ──────────────────────────────────────────────────────────
esp_err_t ble_mesh_init(void)
{
    memset(s_nodes, 0, sizeof(s_nodes));

    esp_err_t err;

    // BLE initialisieren
    err = esp_ble_mesh_init(&s_provision, &s_composition);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "esp_ble_mesh_init fehlgeschlagen: %s", esp_err_to_name(err));
        return err;
    }

    // Callbacks registrieren
    esp_ble_mesh_register_prov_callback(ble_mesh_provisioning_cb);
    esp_ble_mesh_register_generic_client_callback(generic_client_cb);
    esp_ble_mesh_register_sensor_client_callback(sensor_client_cb);
    esp_ble_mesh_register_scene_client_callback(scene_client_cb);
    esp_ble_mesh_register_config_client_callback(config_client_cb);

    // Provisioner mit Network-Key starten
    err = esp_ble_mesh_provisioner_set_node_name(0, "Steinel-Bridge");
    err = esp_ble_mesh_provisioner_add_local_net_key(s_net_key, s_net_idx);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Net-Key hinzufügen fehlgeschlagen: %s", esp_err_to_name(err));
        return err;
    }

    err = esp_ble_mesh_provisioner_add_local_app_key(s_app_key, s_net_idx, s_app_idx);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "App-Key hinzufügen fehlgeschlagen: %s", esp_err_to_name(err));
        return err;
    }

    // Provisioner aktivieren (beginnt mit dem Scan nach Geräten)
    err = esp_ble_mesh_provisioner_prov_enable(ESP_BLE_MESH_PROV_ADV |
                                                ESP_BLE_MESH_PROV_GATT);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Provisioner aktivieren fehlgeschlagen: %s", esp_err_to_name(err));
        return err;
    }

    // Zur Gruppen-Adresse anmelden (um Sensor-Publishes zu empfangen)
    err = esp_ble_mesh_provisioner_add_local_app_key(s_app_key, s_net_idx, s_app_idx);
    esp_ble_mesh_provisioner_bind_app_key_to_local_model(
        esp_ble_mesh_get_primary_element_address(),
        s_app_idx,
        ESP_BLE_MESH_MODEL_ID_SENSOR_CLI,
        0xFFFF);

    ESP_LOGI(TAG, "BLE Mesh Provisioner initialisiert");
    return ESP_OK;
}

void ble_mesh_register_callbacks(steinel_node_added_cb_t on_added,
                                  steinel_state_changed_cb_t on_changed)
{
    s_on_added   = on_added;
    s_on_changed = on_changed;
}

int ble_mesh_get_node_count(void) { return s_node_count; }

const steinel_node_t *ble_mesh_get_node(int index)
{
    if (index < 0 || index >= s_node_count) return NULL;
    return &s_nodes[index];
}

const steinel_node_t *ble_mesh_find_node_by_addr(uint16_t addr)
{
    for (int i = 0; i < s_node_count; i++) {
        if (s_nodes[i].unicast_addr == addr) return &s_nodes[i];
    }
    return NULL;
}

// ─── Lichtsteuerung ───────────────────────────────────────────────────────────
static esp_ble_mesh_client_common_param_t make_param(uint16_t addr, uint32_t opcode)
{
    return (esp_ble_mesh_client_common_param_t){
        .opcode       = opcode,
        .model        = s_root_models + 1,  // GenOnOff Client
        .ctx.net_idx  = s_net_idx,
        .ctx.app_idx  = s_app_idx,
        .ctx.addr     = addr,
        .ctx.send_ttl = 3,
        .msg_role     = ROLE_PROVISIONER,
        .msg_timeout  = 4000,
    };
}

esp_err_t steinel_set_onoff(uint16_t addr, bool on)
{
    esp_ble_mesh_generic_client_set_state_t set = {
        .onoff_set.op_en  = false,
        .onoff_set.onoff  = on ? 1 : 0,
        .onoff_set.tid    = s_prov_tid++,
    };
    esp_ble_mesh_client_common_param_t p =
        make_param(addr, ESP_BLE_MESH_MODEL_OP_GEN_ONOFF_SET);
    return esp_ble_mesh_generic_client_set_state(&p, &set);
}

esp_err_t steinel_set_lightness(uint16_t addr, uint16_t lightness)
{
    esp_ble_mesh_lighting_client_set_state_t set = {
        .lightness_set.lightness = lightness,
        .lightness_set.tid       = s_prov_tid++,
        .lightness_set.op_en     = false,
    };
    esp_ble_mesh_client_common_param_t p =
        make_param(addr, ESP_BLE_MESH_MODEL_OP_LIGHT_LIGHTNESS_SET);
    p.model = s_root_models + 3;  // Light Lightness Client
    return esp_ble_mesh_light_client_set_state(&p, &set);
}

esp_err_t steinel_set_base_lightness(uint16_t addr, uint16_t level)
{
    // Grundlicht wird über Generic Level als "Power On Default" gespeichert
    steinel_node_t *node = find_or_create_node(addr);
    if (!node) return ESP_ERR_NO_MEM;
    node->base_lightness = level;

    // Szene 1 (Auto-Modus) mit dem neuen Grundlicht-Level speichern
    esp_ble_mesh_lighting_client_set_state_t set = {
        .lightness_default_set.lightness = level,
    };
    esp_ble_mesh_client_common_param_t p =
        make_param(addr, ESP_BLE_MESH_MODEL_OP_LIGHT_LIGHTNESS_DEFAULT_SET);
    p.model = s_root_models + 3;
    return esp_ble_mesh_light_client_set_state(&p, &set);
}

esp_err_t steinel_set_transition_time_ms(uint16_t addr, uint32_t ms)
{
    // BLE Mesh Transition Time Encoding
    uint8_t steps, resolution;
    if (ms <= 6200) {       // 100ms Schritte
        steps      = ms / 100;
        resolution = 0x00;
    } else if (ms <= 62000) { // 1s Schritte
        steps      = ms / 1000;
        resolution = 0x01;
    } else if (ms <= 620000) { // 10s Schritte
        steps      = ms / 10000;
        resolution = 0x02;
    } else {                   // 10min Schritte
        steps      = ms / 600000;
        resolution = 0x03;
    }
    if (steps > 0x3E) steps = 0x3E;

    esp_ble_mesh_generic_client_set_state_t set = {
        .def_trans_time_set.trans_time = (resolution << 6) | (steps & 0x3F),
    };
    esp_ble_mesh_client_common_param_t p =
        make_param(addr, ESP_BLE_MESH_MODEL_OP_GEN_DEF_TRANS_TIME_SET);
    p.model = s_root_models + 6;  // DTT Client
    return esp_ble_mesh_generic_client_set_state(&p, &set);
}

esp_err_t steinel_set_continuous_mode(uint16_t addr, bool continuous)
{
    // Szene 2 = Dauerlicht, Szene 1 = Auto
    return steinel_recall_scene(addr, continuous ? 2 : 1);
}

esp_err_t steinel_set_hold_time(uint16_t addr, uint32_t seconds)
{
    steinel_node_t *node = find_or_create_node(addr);
    if (!node) return ESP_ERR_NO_MEM;
    node->hold_time_s = seconds;

    // Sensor-Cadence für "Time Since Motion" setzen
    esp_ble_mesh_sensor_client_set_state_t set = {0};
    set.sensor_cadence_set.property_id           = SENSOR_PROP_TIME_SINCE_MOTION;
    set.sensor_cadence_set.fast_cadence_period_div = 2;
    set.sensor_cadence_set.status_trigger_type   = 0;
    // Trigger-Delta auf hold_time setzen (in 0.01-Sekunden-Einheiten)
    // Vereinfacht: raw_value_rising = hold_time * 100
    set.sensor_cadence_set.status_min_interval   = 7;  // ~1,28s

    esp_ble_mesh_client_common_param_t p =
        make_param(addr, ESP_BLE_MESH_MODEL_OP_SENSOR_CADENCE_SET);
    p.model = s_root_models + 4;  // Sensor Client
    return esp_ble_mesh_sensor_client_set_state(&p, &set);
}

esp_err_t steinel_set_sensitivity(uint16_t addr, uint8_t level)
{
    steinel_node_t *node = find_or_create_node(addr);
    if (!node) return ESP_ERR_NO_MEM;
    node->sensitivity = level;
    // Empfindlichkeit über Sensor-Cadence min-interval regeln
    // 0=low (weniger sensitiv = längeres Intervall), 2=high (kurz)
    uint8_t intervals[] = {9, 7, 5};  // 2.56s, 0.64s, 0.16s
    esp_ble_mesh_sensor_client_set_state_t set = {0};
    set.sensor_cadence_set.property_id         = SENSOR_PROP_MOTION_SENSED;
    set.sensor_cadence_set.status_min_interval  = intervals[level < 3 ? level : 1];

    esp_ble_mesh_client_common_param_t p =
        make_param(addr, ESP_BLE_MESH_MODEL_OP_SENSOR_CADENCE_SET);
    p.model = s_root_models + 4;
    return esp_ble_mesh_sensor_client_set_state(&p, &set);
}

esp_err_t steinel_set_twilight_threshold(uint16_t addr, uint16_t lux)
{
    steinel_node_t *node = find_or_create_node(addr);
    if (!node) return ESP_ERR_NO_MEM;
    node->twilight_lux = lux;

    // Sensor-Settings für Ambient Light Level
    esp_ble_mesh_sensor_client_set_state_t set = {0};
    set.sensor_setting_set.property_id         = SENSOR_PROP_AMBIENT_LIGHT_LEVEL;
    set.sensor_setting_set.sensor_setting_property_id = 0x0042; // Setting Property

    esp_ble_mesh_client_common_param_t p =
        make_param(addr, ESP_BLE_MESH_MODEL_OP_SENSOR_SETTING_SET);
    p.model = s_root_models + 4;
    return esp_ble_mesh_sensor_client_set_state(&p, &set);
}

esp_err_t steinel_recall_scene(uint16_t addr, uint8_t scene_number)
{
    esp_ble_mesh_scene_client_set_state_t set = {
        .scene_recall.op_en      = false,
        .scene_recall.scene_number = scene_number,
        .scene_recall.tid        = s_prov_tid++,
    };
    esp_ble_mesh_client_common_param_t p =
        make_param(addr, ESP_BLE_MESH_MODEL_OP_SCENE_RECALL);
    p.model = s_root_models + 5;  // Scene Client
    return esp_ble_mesh_scene_client_set_state(&p, &set);
}

esp_err_t steinel_store_scene(uint16_t addr, uint8_t scene_number)
{
    esp_ble_mesh_scene_client_set_state_t set = {
        .scene_store.scene_number = scene_number,
    };
    esp_ble_mesh_client_common_param_t p =
        make_param(addr, ESP_BLE_MESH_MODEL_OP_SCENE_STORE);
    p.model = s_root_models + 5;
    return esp_ble_mesh_scene_client_set_state(&p, &set);
}

esp_err_t steinel_set_schedule(uint16_t addr, uint8_t entry_index,
                                uint8_t hour, uint8_t minute,
                                uint8_t action, uint8_t scene_number)
{
    // BLE Mesh Scheduler Register Entry
    // Bitfelder: Year(7)|Month(12)|Day(5)|Hour(5)|Minute(6)|Second(6)|
    //            DayOfWeek(7)|Action(4)|TransTime(8)|SceneNumber(16)
    esp_ble_mesh_time_scene_client_set_state_t set = {0};
    set.scheduler_act_set.index   = entry_index;
    set.scheduler_act_set.year    = 0x64;   // jedes Jahr
    set.scheduler_act_set.month   = 0x0FFF; // jeden Monat
    set.scheduler_act_set.day     = 0x00;   // jeden Tag
    set.scheduler_act_set.hour    = hour;
    set.scheduler_act_set.minute  = minute;
    set.scheduler_act_set.second  = 0x00;
    set.scheduler_act_set.day_of_week = 0x7F;  // alle Wochentage
    set.scheduler_act_set.action  = action;
    set.scheduler_act_set.trans_time = 0;
    set.scheduler_act_set.scene_number = scene_number;

    esp_ble_mesh_client_common_param_t p =
        make_param(addr, ESP_BLE_MESH_MODEL_OP_SCHEDULER_ACT_SET);
    p.model = s_root_models + 0;  // verwende Config Client slot – später Scheduler Client
    return esp_ble_mesh_time_scene_client_set_state(&p, &set);
}

esp_err_t steinel_request_sensor_data(uint16_t addr)
{
    esp_ble_mesh_sensor_client_get_state_t get = {
        .sensor_get.op_en = false,
    };
    esp_ble_mesh_client_common_param_t p =
        make_param(addr, ESP_BLE_MESH_MODEL_OP_SENSOR_GET);
    p.model = s_root_models + 4;
    return esp_ble_mesh_sensor_client_get_state(&p, &get);
}
