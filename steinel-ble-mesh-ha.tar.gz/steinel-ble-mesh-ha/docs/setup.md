# Setup-Anleitung

## Schritt 1: ESP-IDF einrichten

### Linux / macOS
```bash
mkdir -p ~/esp
cd ~/esp
git clone --recursive https://github.com/espressif/esp-idf.git
cd esp-idf
git checkout v5.2.1   # empfohlene stabile Version
./install.sh esp32
```

Jedes Mal vor der Arbeit am Projekt:
```bash
. ~/esp/esp-idf/export.sh
```

### Windows
ESP-IDF Installer herunterladen: https://dl.espressif.com/dl/esp-idf/

## Schritt 2: Projekt bauen

```bash
cd steinel-ble-mesh-ha/esp32_firmware

# Konfiguration (WiFi, MQTT)
idf.py menuconfig

# Bauen
idf.py build

# Flashen (Port anpassen)
idf.py -p /dev/ttyUSB0 flash

# Monitor
idf.py -p /dev/ttyUSB0 monitor
```

## Schritt 3: Mesh-Keys sichern

Vor dem ersten Flash die Keys in `ble_mesh.c` anpassen:
```bash
python3 -c "import os; print(', '.join(hex(b) for b in os.urandom(16)))"
```

## Schritt 4: Leuchte provisionieren

1. Steinel L 810 SC 3× kurz aus-/einschalten → blinkt kurz
2. ESP32 erkennt die Leuchte automatisch (< 30 Sekunden)
3. Im Monitor: `✅ Gerät provisioniert: Adresse=0x0001`

## Schritt 5: Home Assistant

1. Mosquitto Broker Add-on installieren (HA Add-on Store)
2. MQTT Integration einrichten (*Einstellungen → Integrationen → MQTT*)
3. Entities erscheinen automatisch durch MQTT Discovery

## Tipps

- ESP32 möglichst zentral platzieren (Bluetooth-Reichweite ~10–15 m outdoors)
- Bei mehreren Leuchten: ESP32 als Relay-Node fungiert automatisch als Mesh-Verstärker
- NVS-Flash löschen nach Key-Änderung: `idf.py erase-flash`
